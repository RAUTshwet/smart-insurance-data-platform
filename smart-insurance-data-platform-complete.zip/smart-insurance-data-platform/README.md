# Smart Insurance Data Platform

End-to-end insurance data engineering project using Python, SQL, PySpark and Medallion Architecture.

## Dataset

- 100 customers
- 150 policies
- 200 claims
- 250 payments

## Architecture

```text
Raw CSV
   ↓
Bronze
   ↓
Data Quality
   ↓
Silver
   ↓
Gold
   ↓
SQL Analytics
   ↓
Power BI
```

## Technologies

Python | Pandas | SQL | PySpark | Databricks concepts | Delta Lake concepts | Power BI | GitHub

## Run locally

```bash
pip install -r requirements.txt
python python/run_pipeline.py
```

The Gold outputs are generated under `data/gold/`.

## Gold datasets

- customer_360.csv
- policy_summary.csv
- claims_by_type.csv
- payment_summary.csv

## Business KPIs

- Total policies
- Active policies
- Total premium
- Total claims
- Total claim amount
- Approved claim amount
- Total payments
- Claim-to-premium ratio
- Payment status
- Claims by type

## Project objective

Build a scalable insurance data platform that ingests raw insurance data, validates and transforms it through Bronze, Silver and Gold layers, and prepares business-ready datasets for SQL analytics and Power BI visualization.
